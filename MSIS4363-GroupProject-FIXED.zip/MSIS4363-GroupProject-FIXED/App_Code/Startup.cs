﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MSIS4363_GroupProject_LOCALTEST.Startup))]
namespace MSIS4363_GroupProject_LOCALTEST
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
